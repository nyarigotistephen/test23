
from django.db.models.query import QuerySet
from django.http import response
from django.shortcuts import render

# Create your views here.
from django.shortcuts import get_list_or_404
from django.views import generic
from rest_framework import generics 
from rest_framework import serializers
from rest_framework.exceptions import server_error
from rest_framework.serializers import Serializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import *
from .serializer import *
from api import serializer




# class dateslist(APIView):
#     def get_object(self):
#       try:
#         return Dates.objects.all()
#       except Dates.DoesNotExist:
#         raise status.HTTP_404_NOT_FOUND



#     def get(self, request, format=None):
#       dates = self.get_object()
#       serializer = Datesserializer(dates, many=True)
#       return Response(data=serializer.data,status=status.HTTP_200_OK)

#     def post(self, request):
#         request_data = request.data
#         serializer = Datesserializer(data=request_data)
#         if serializer.is_valid():
#           serializer.save()
#           return Response(serializer.data, status=201) 
#         return Response(serializer.errors, status=400)
        
#     def post(self, request):
#       serializer = Datesserializer(data=request.data)
#       try:
#        if serializer.is_valid():
#          serializer.save()
#          return Response(serializer.data, status=status.HTTP_201_CREATED)
#       except Exception as e:
#         print(e)
#         return Response(serializer._errors, status=status.HTTP_404_NOT_FOUND)
#     def put(self, request):
#       data = Dates.objects.get(id= request.data['id'])
#       serializer = Datesserializer(data, data=request.data)
#       if serializer.is_valid():
#         serializer.save()
#         return Response(data=serializer.data, status=status.HTTP_202_ACCEPTED)
#       return Response(server_error, status=status.HTTP_404_NOT_FOUND)

class userlist(generics.ListCreateAPIView,
              generics.RetrieveAPIView,
              generics.UpdateAPIView,
              generics.DestroyAPIView):


   queryset= User.objects.all()
   serializer_class =Userserializer

 
class smslist(generics.ListCreateAPIView,
              generics.RetrieveAPIView,
              generics.UpdateAPIView,
              generics.DestroyAPIView):


   queryset= Sms.objects.all()
   serializer_class =Smsserializer
  
    
class detaillist(generics.ListCreateAPIView,
              generics.RetrieveAPIView,
              generics.UpdateAPIView,
              generics.DestroyAPIView):


   queryset= Detail.objects.all()
   serializer_class =Detailserializer
  
class myselflist(generics.ListCreateAPIView,
              generics.RetrieveAPIView,
              generics.UpdateAPIView,
              generics.DestroyAPIView):


   queryset= Myself.objects.all()
   serializer_class =Myselfserializer
  
   
class matchlist(APIView):

    def get(self, request):
      match = Match.objects.all()
      serializer = Matchserializer(match, many=True)
      return Response(serializer.data)

    def post():
        pass

# class userlist(APIView):
#   def get(self, request):
#     users = User.objects.all()
#     serializer = Userserializer(users, many=True)
#     return Response(serializer.data)


#   def post():
#         pass

# class smslist(APIView):
#   def get(self, request):
#     sms = Sms.objects.all()
#     serializer = Smsserializer(sms, many=True)
#     return Response(serializer.data)

    
#   def post(self, request):
#         request_data = request.data
#         serializer = Smsserializer(data=request_data)
#         if serializer.is_valid():
#           serializer.save()
#           return Response(serializer.data, status=201) 
#         return Response(serializer.errors, status=400)

class locationlist(APIView):
  def get(self, request):
    location = Location.objects.all()
    serializer = Locationserializer(location, many=True)
    return Response(serializer.data)

    
    def post():
        pass