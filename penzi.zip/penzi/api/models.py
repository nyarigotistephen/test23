from django.db import models
from django.db.models.aggregates import Max
from django.db.models.fields.related import ForeignKey

class Dates(models.Model):
    matched = models.CharField(max_length=10)
    open = models.FloatField()
    close = models.FloatField()
    volume = models.CharField(max_length=12)

    def __str__(self):
        return self.matched



class User(models.Model):
    phonenumber = models.CharField(max_length=200, unique=True)
    name = models.CharField(max_length=200, null=True)
    age = models.CharField(max_length=200, null=True)
    gender = models.CharField(max_length=200, null=True)
    province = models.CharField(max_length=200, null=True)
    town = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.name

class Detail(models.Model):
    religion = models.CharField(max_length=200, null=True)
    tribe = models.CharField(max_length=200, null=True)
    status = models.CharField(max_length=200, null=True)
    profession = models.CharField(max_length=200, null=True)
    education = models.CharField(max_length=200, null=True)
    joining_date = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.religion


class Myself(models.Model):
    Myself = models.CharField(max_length=200, null=True)

    def __str__(self):
        return self.Myself

class Sms(models.Model):
    messages = models.CharField(max_length=200, null=True)
    mto = models.CharField(max_length=200, null=True)
    mfrom = models.CharField(max_length=200, null=True)



    def __str__(self):
        return self.messages

class Match(models.Model):
    age = models.CharField(max_length=200, null=True)
    province = models.CharField(max_length=200, null=True)
    town= models.CharField(max_length=200, null=True)



    def __str__(self):
        return self.age


class Location(models.Model):
    province = models.CharField(max_length=200, null=True)
    town = models.CharField(max_length=200, null=True)

    def _str_(self):
        return self.province





# class User(models.Model):
#     name = models.CharField(max_length=200, null=True)
#     phonenumber = models.CharField(max_length=200, unique=True)
#     age = models.CharField(max_length=200, null=True)
#     gender = models.CharField(max_length=200, null=True)
#     tribe = models.CharField(max_length=200, null=True)
#     religion = models.CharField(max_length=200, null=True)
#     town = models.CharField(max_length=200, null=True)
#     marital = models.CharField(max_length=200, null=True)
#     province = models.CharField(max_length=200, null=True)
#     myself = models.CharField(max_length=200, null=True)
#     matchs = models.CharField(max_length=200, null=True)
#     matched = models.CharField(max_length=200, null=True)
#     education = models.CharField(max_length=200, null=True)
#     joining_date = models.DateTimeField(auto_now_add=True, null=True)


#     def __str__(self):
#         return self.name

# class Match(models.Model):
#     name = models.CharField(max_length=200, null=True)
#     phonenumber = models.CharField(max_length=200, null=True)
#     age = models.CharField(max_length=200, null=True)
#     gender = models.CharField(max_length=200, null=True)
#     tribe = models.CharField(max_length=200, null=True)
#     religion = models.CharField(max_length=200, null=True)
#     town = models.CharField(max_length=200, null=True)
#     province = models.CharField(max_length=200, null=True)
#     education = models.CharField(max_length=200, null=True)
#     joining_date = models.DateTimeField(auto_now_add=True, null=True)

#     def __str__(self):
#         return self.name
        

