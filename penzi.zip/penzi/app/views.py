from django.core.checks import messages
from django.db.models.query import prefetch_related_objects
import requests
import json

from api.views import Sms
from django.shortcuts import redirect, render
from django.urls import reverse

# Create your views here.
from api.models import Sms
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from api.models import *
from .filter import *
#from .form import *


# def validate(message):
#     if message.startswith("penzi"):

#         return("register")
#     else:
#         return render("request, 'penzi/home.html',context")

def home(request):

    
   # register = requests.post(request.build_absolute_uri(reverse("home")))
    if request.method == 'POST':
        messages =request.POST['messages']
        mfrom =request.POST['phone']
        mto =request.POST['mto']
        
        
        print(F"............................................{messages}")
        print(F"............................................{mfrom}")

        x = User(phonenumber=mfrom)
        x.save()    
        ins = Sms(messages=messages,mto=mto, mfrom=mfrom) 
        ins.save()

        if messages.lower() == "penzi":
            return redirect(f"{reverse('register')}?phone={mfrom}")
            #return redirect("register")

    context= {
        "welcome": "welcome to penzi sms penzi to 5001 to get started ",
    }   
    return render(request, 'penzi/home.html',context)

def dating(request):
    dates=User.objects.all()
    phonen = request.GET['phone']
    
    message=Sms.objects.all().filter(mfrom=phonen)
    # users = User.objects.filter(age__range=(10, 50))

    if request.method == 'POST':
        number=request.POST['number']
         
        ins =User(matched=number)
        ins.save()
        #if number  
        return redirect(f"{reverse('matched')}?phone={phonen}")

    
    
    context= {
        "sms":message,
        "user": dates,
        #"message": "welcome to our dating services with 600 potential dating partners to register sms start  #name#age#sex#province#town to penzi 5001",
        
      }
    return render(request, 'penzi/dating.html',context) 


def matched(request):
    dates=Match.objects.all()
    phone = request.GET['phone']
    

    context= {
        #"sms":dates,
        "user": dates,
        #"message": "welcome to our dating services with 600 potential dating partners to register sms start  #name#age#sex#province#town to penzi 5001",
        
      }

    return render(request, 'penzi/matched.html',context) 



def myself(request):

    phone = request.GET['phone']
    if request.method == 'POST':
        matchs =request.POST['match'] 

        ins = Match(age=matchs)
        ins.save()

        if matchs.lower() == "matchs":
          return redirect(f"{reverse('dating')}?phone={phone}")

    context= {
        #"matchs":match,
        #"message": "welcome to our dating services with 600 potential dating partners to register sms start  #name#age#sex#province#town to penzi 5001",
        
     }
    
    return render(request, 'penzi/myself.html',context)

def register(request):
    register = requests.post(request.build_absolute_uri(reverse("dates")))
    phone =request.GET['phone']


    if request.method == 'POST':
        name =request.POST['name']
        
        x = name.split("#")
        print("x")
        if len(x) == 6:
            nm = x[1]
            age = x[2]
            gender = x[3]
            province =x[4]
            town = x[5]

            ins = User(name=nm, age=age, gender=gender, province= province, town=town) 
            ins.save()
            return redirect(f"{reverse('details')}?phone={phone}")
            #return redirect("details")

    message=Sms.objects.all().order_by("id")
   
    context= {
        "sms":message,
        "message": "welcome to our dating services with 600 potential dating partners to register sms start  #name#age#sex#province#town to penzi 5001",
         "sms": message,
     }
    return render(request, 'penzi/register.html',context)


def details(request):
    # # data = request.POST.get('name')
    # data = requests.get(request.build_absolute_uri(reverse("dates")))
    # data = json.loads(data.text)
    # print(data)
    phone = request.GET['phone']  

    if request.method == 'POST':
        details =request.POST['name']
        
        x = details.split("#")
        print("x")
        if len(x) == 6:
            level = x[1]
            profession = x[2]
            marital = x[3]
            religion =x[4]
            tribe = x[5]

            ins = Detail(education=level, profession=profession, status=marital, religion= religion, tribe=tribe) 
            ins.save()

            return redirect(f"{reverse('describe')}?phone={phone}")

    message=Sms.objects.all().order_by("-id")
   
    context= {
        "sms":message,
        "message": "welcome to our dating services with 600 potential dating partners to register sms start  #name#age#sex#province#town to penzi 5001",
         "sms": message,
     }

    return render(request, 'penzi/details.html',context)



def describe(request):

    # data = requests.get(request.build_absolute_uri(reverse("dates")))
    # data = json.loads(data.text)
    phone = request.GET["phone"]
    if request.method == 'POST':
        describe =request.POST['name']
        

        ins = Myself(Myself=describe)
        ins.save()
        return redirect(f"{reverse('myself')}?phone={phone}")

    message=Sms.objects.all().order_by("id")
   
    context= {
        "sms":message,
        "message": "welcome to our dating services with 600 potential dating partners to register sms start  #name#age#sex#province#town to penzi 5001",
         
     }
    #return render(f"{reverse('describe')}?phone={phone}")
    return render(request, 'penzi/describe.html',context)

