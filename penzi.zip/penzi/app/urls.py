from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from . import views

urlpatterns = [
   
    path('',views.home),
    path('register',views.register, name="register"),
    path('register/details',views.details, name="details"),
    path('register/details/describe',views.describe, name="describe"),
    path('register/details/describe/myself',views.myself, name="myself"),
    path('register/details/describe/myself/dating',views.dating, name="dating"),
    path('register/details/describe/myself/dating/matched',views.matched, name="matched"),
]

